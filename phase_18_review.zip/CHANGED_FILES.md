# Changed Files - Phase 18

## Modified Files

### Scripts (Legacy Wrappers)
1. **scripts/compliance.py** - Reduced to thin wrapper importing `ComplianceEngine` from `services.compliance`
2. **scripts/setup_tools.py** - Updated imports: `Database` from `services.infrastructure.database`
3. **scripts/telegram_bot.py** - Updated imports: `Database` from `services.infrastructure.database`, `ComplianceEngine` from `services.compliance`
4. **scripts/video_processor.py** - Updated imports: all `lib.*` replaced with `services.utils.*`, `transform_video.*` replaced with `services.transform.*`, `caption_policy.*` replaced with `services.compliance.caption_policy.*`

### Services Layer (Canonical Implementations)
5. **services/core/video_service.py** - Updated imports: `caption_policy` from `services.compliance.caption_policy`, `transform_video` from `services.transform`
6. **services/infrastructure/ai_adapter.py** - Updated imports: `caption_policy` from `services.compliance.caption_policy`

### New Services Modules
7. **services/compliance/__init__.py** - Exports all compliance public API
8. **services/compliance/caption_policy.py** - Canonical caption policy rules (copied from scripts/caption_policy.py)
9. **services/compliance/compliance_engine.py** - Canonical ComplianceEngine (refactored from scripts/compliance.py)
10. **services/transform/__init__.py** - Exports all transform public API
11. **services/transform/video_transformer.py** - Canonical transform logic (refactored from scripts/transform_video.py)

### Test Files (Updated Imports)
12. **tests/conftest.py** - Uses `TESTING=1` env, `services.infrastructure.config.Config`, `services.utils.paths.db_path`
13. **tests/e2e_test_env.py** - Uses `services.infrastructure.config.Config` only (removed scripts.config)
14. **tests/test_competitor_scraper.py** - Imports `Database` from `services.infrastructure.database`
15. **tests/test_compliance.py** - Imports from `services.compliance.caption_policy` and `services.compliance.ComplianceEngine`
16. **tests/test_e2e_pipeline.py** - Imports `ComplianceEngine` from `services.compliance`
17. **tests/test_sync_out.py** - Imports `Database` from `services.infrastructure.database`
18. **tests/test_uploader.py** - Mocks config via `services.infrastructure.config` (still uses `lib` for proxy utils)
19. **tests/test_video_processor.py** - Imports `scan_caption` from `services.compliance.caption_policy`
20. **tests/test_sync_out.py** - Imports `Database` from `services.infrastructure.database`
21. **webapp/server.py** - Imports `ComplianceEngine` from `services.compliance`

### Configuration
22. **pytest.ini** - Added `TESTING = 1` env variable

## Summary
- **Modified**: 22 files
- **Added**: 5 new service modules
- **Deleted**: 0 files (legacy scripts remain as thin wrappers for backward compatibility)